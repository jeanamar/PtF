from .file import FileSink
from .delta import DeltaSink